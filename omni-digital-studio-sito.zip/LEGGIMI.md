# OMNI Digital Studio — sito (prima bozza)

Sito statico, zero dipendenze: si apre con doppio click su `index.html` e si pubblica
caricando la cartella su qualsiasi hosting (Netlify, Vercel, Aruba, Altervista…).

```
index.html                 tutta la pagina
assets/css/style.css       stili (desktop + mobile in fondo al file)
assets/js/main.js          animazioni e interazioni
assets/img/logo-mark.svg   simbolo del logo (ricostruito in vettoriale)
assets/img/favicon.svg     icona della scheda browser
robots.txt · sitemap.xml   per l'indicizzazione su Google
dist/ · build-artifact.sh  solo per l'anteprima online, non serve per il sito
```

## Da sostituire prima di andare online

| Dove | Cosa |
|---|---|
| Tutto il file `index.html` | telefono `320 119 1509`, mail `ciao@omnidigitalstudio.it`, P.IVA, città |
| Sezione hero, "Lavori", footer | **i numeri sono segnaposto** (+120 progetti, 4.9/5, 212%, #1 su Google…) |
| Sezione "Lavori" | nomi clienti e risultati inventati: da sostituire con casi reali |
| Sezione "Prezzi" | le cifre (500 / 890 / 2.500 €) |
| `<link rel="canonical">`, `og:url`, `sitemap.xml`, `robots.txt` | il dominio vero |
| `assets/img/logo-mark.svg` | se hai il logo originale in SVG/PNG, sostituiscilo |

## Animazioni incluse

- preloader con il logo che si disegna
- hero con aurora animata su canvas + titolo che entra parola per parola
- bottoni magnetici, card con inclinazione 3D
- "Metodo": sezione bloccata che scorre in orizzontale (su telefono diventa uno swipe)
- iPhone in 3D che ruota mentre scorri
- contatori animati, ticker infinito, FAQ a fisarmonica
- footer nero con la scritta OMNI in dissolvenza

Tutto si disattiva da solo se il sistema ha attivo "riduci animazioni".

## SEO già impostata

Title e description con le parole chiave, dati strutturati `ProfessionalService`,
heading in ordine (un solo `<h1>`), sitemap, robots, testi brevi e mirati su:
*creazione siti web, realizzazione siti internet, e-commerce, ottimizzazione SEO,
restyling sito, landing page, web agency*.

## Mobile

Breakpoint a 1080 / 860 / 720 / 620 / 380 px. Su telefono: menu a tutto schermo,
barra fissa in basso con "Chiama" e "Preventivo gratuito", metodo a swipe,
tipografia e spazi ricalibrati.
